﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ABCSpares
{
    class Logger
    {
        public Logger()
        {

        }
        //public void Write();//write to file
        
    }
}
