﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace ABCSpares
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
            LVVehiclelst.ItemsSource = vehicleLst;
        }
        //create variables
        string vMake;
        string vModel;
        string vYear;
        int vPrice;

        //Create a list of objects
        List<Vehicle> vehicleLst = new List<Vehicle>();

        

        private void reportbtn_Click(object sender, RoutedEventArgs e)
        {

            vMake = maketxt.Text.ToString();
            vModel = modeltxt.Text.ToString();
            vYear = yeartxt.Text.ToString();
            vPrice = Convert.ToInt32(pricetxt.Text.ToString());//convert string to int

            string vehicle = "Make: " + vMake + "\t\t" + "Model: " + vModel + "\t\t" + "Year: " + vYear + "\t\t" + "Price: R" + vPrice;
            Vehicle objvehicle = new Vehicle(vMake, vModel, vYear, vPrice);//create object before adding to list
            //create a vehicle and add to list
            vehicleLst.Add(objvehicle);
            //set item source to empty string
            // LVVehiclelst.ItemsSource = "";
            //LVVehiclelst.ItemsSource = vehicleLst;

            //if (maketxt.Text.Equals("") && modeltxt.Text.Equals("") && yeartxt.Text.Equals("") && pricetxt.Text.Equals(""))
            //{
            //    string vehicle = "Make: " + vMake + "\t\t" + "Model: " + vModel + "\t\t" + "Year: " + vYear + "\t\t" + "Price: R" + vPrice;

            //    Vehicle objvehicle = new Vehicle(vMake, vModel, vYear, vPrice);//create object before adding to list
            //    //create a vehicle and add to list
            //    vehicleLst.Add(objvehicle);

            //    //string vehicle = "Make: " + maketxt.Text + "\t\t" + "Model: " + modeltxt.Text + "\t\t" + "Year: " + yeartxt + "\t\t" + "Price: R" + pricetxt;
            //    //Vehicle objvehicle = new Vehicle(vMake, vModel, vYear, vPrice);//create object before adding to list
            //    ////create a vehicle and add to list
            //    //vehicleLst.Add(objvehicle);
            //}
            //else
            //{
            //    string vehicle = "Make: " + vMake + "\t\t" + "Model: " + vModel + "\t\t" + "Year: " + vYear + "\t\t" + "Price: R" + vPrice;

            //    Vehicle objvehicle = new Vehicle(vMake, vModel, vYear, vPrice);//create object before adding to list
            //    //create a vehicle and add to list
            //    vehicleLst.Add(objvehicle);
            //}
            if(vMake == "" || vModel == "" || vYear == "")
            {
                MessageBox.Show("Please ensure all fields are entered");
            }
            else
            {
                MessageBox.Show("You have entered:\n" + vMake + "\n " + vModel + "\n " + vYear + "\n " + "with a value of: R"+ vPrice);
            }


        }
    }
}
