﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ABCSpares
{
    class Vehicle
    {
        //zcreated variables
        string make;
        string model;
        string year;
        int price;

        public Vehicle()//blank constructor
        {

        }

        public Vehicle(string make, string model, string year, int price)//set constructor
        {
            this.make = make;
            this.model = model;
            this.year = year;
            this.price = price;
        }
        //generate gettters and setters
        public string Make { get => make; set => make = value; }
        public string Model { get => model; set => model = value; }
        public string Year { get => year; set => year = value; }
        public int Price { get => price; set => price = value; }
    }
}
